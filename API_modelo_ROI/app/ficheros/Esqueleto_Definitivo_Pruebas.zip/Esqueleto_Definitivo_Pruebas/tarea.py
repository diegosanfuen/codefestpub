import logging
def mi_tarea():
    # Configurar el módulo de registro
    logging.basicConfig(filename='Log/app.log', level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

    # Ejemplos de mensajes de registro
    #logging.debug('Este es un mensaje de depuración')
    logging.info('¡Tarea ejecutada!')
    #logging.warning('Este es un mensaje de advertencia')
    #logging.error('Este es un mensaje de error')
    #logging.critical('Este es un mensaje crítico')

    # Aquí va tu código que deseas ejecutar
    print("¡Tarea ejecutada!")
    

# Ejecutar la tarea inicialmente
mi_tarea()
